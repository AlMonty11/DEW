﻿using Jardineria.Data;
using Jardineria.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.Data;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Jardineria.Controllers
{
    [Route("api/Auth")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<JardinUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
      /*  private readonly SignInManager<IdentityUser> _signInManager;*/
        private readonly jardineriaContext _jardineriaContext;
        private readonly IConfiguration _configuration;

        public AuthController(
            UserManager<JardinUser> userManager,
            RoleManager<IdentityRole> roleManager,
/*            SignInManager<IdentityUser> signInManager,*/
            jardineriaContext jardineriaContext,
             IConfiguration configuration)
        {
            _userManager = userManager;
            _roleManager = roleManager;
          /*  _signInManager = signInManager;*/
            _jardineriaContext = jardineriaContext;
            _configuration = configuration;
        }

        // Acción para el Login
        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] Login login)
        {
            if (!string.IsNullOrEmpty(login.email) && !string.IsNullOrEmpty(login.password))
            {
                var user = await _userManager.FindByEmailAsync(login.email.ToUpper());
                if (user != null && await _userManager.CheckPasswordAsync(user, login.password))
                {
                    var claims = new List<Claim>
                    {
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                    new Claim(JwtRegisteredClaimNames.Iat, DateTime.UtcNow.ToString()),
                    new Claim(JwtRegisteredClaimNames.Sub, user.UserName)

                    
                    // Puedes agregar más claims según sea necesario (roles, etc.)
                    };
                    var userRoles = await _userManager.GetRolesAsync(user);
                    foreach (var userRole in userRoles)
                    {
                        claims.Add(new Claim(ClaimTypes.Role, userRole));
                    }

                    var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Key"]));
                    var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                    var token = new JwtSecurityToken(
                        _configuration["JWT:Issuer"],
                        _configuration["JWT:Audience"],
                        claims,
                        expires: DateTime.UtcNow.AddHours(2), // Ajusta la expiración del token según tus necesidades
                        signingCredentials: creds
                    );

                    return Ok(new JwtSecurityTokenHandler().WriteToken(token));
                }
            }

            return Unauthorized();
        }

        // Acción para el Register
        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] Register register)
        {
            if (!string.IsNullOrEmpty(register.email) && !string.IsNullOrEmpty(register.password))
            {
                var user = new JardinUser { UserName = register.email, Email = register.email, FullName = register.FullName,Address= register.Address,PostalCode= register.PostalCode,Phone= register.Phone };
                var result = await _userManager.CreateAsync(user, register.password);

                if (result.Succeeded)
                {
                    // Si trabajas con roles, asigna un rol al usuario
                    await _userManager.AddToRoleAsync(user, "basic");

                    return Ok();
                }

                return BadRequest(result.Errors);
            }

            return BadRequest("Email y contraseña son requeridos.");
        }

        [Authorize(Roles ="Basic")]
        [HttpGet("upgrade")]
        public async Task<IActionResult> Upgrade()
        {
            // Obtener el nombre de usuario del token
            var userName  = User.FindFirstValue(ClaimTypes.NameIdentifier) ;

            if (string.IsNullOrEmpty(userName))
            {
                return Unauthorized("Token no contiene información de usuario válida");
            }

            var user = await _userManager.FindByNameAsync(userName);

            if (user == null)
            {
                return NotFound("Usuario no encontrado");
            }

            var isInBasicRole = await _userManager.IsInRoleAsync(user, "basic");
            var isInPremiumRole = await _userManager.IsInRoleAsync(user, "premium");

            if (isInBasicRole && !isInPremiumRole)
            {
                // Agrega el rol Premium al usuario
                await _userManager.AddToRoleAsync(user, "premium");

                return Ok("Usuario actualizado a Premium exitosamente");
            }


            return BadRequest("El usuario ya es Premium o no tiene el rol Basic");
        }


        //USUARIOS
        [HttpGet("Users")]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Users()
        {
            var users = _userManager.Users.ToList();
            if (users != null)
            {
                return Ok(users);
            }
            return NotFound();
        }


    }

}
