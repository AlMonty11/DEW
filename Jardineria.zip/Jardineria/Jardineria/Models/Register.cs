﻿using System.ComponentModel.DataAnnotations;

namespace Jardineria.Models
{
    public class Register
    {
        public string email { get; set; }
        public string password { get; set; }
        [MinLength(10, ErrorMessage = "El campo debe contener al menos 10 caracteres")]
        public string FullName { get; set; }
        public string? Address { get; set; }

        public int PostalCode { get; set; }
 
        public int Phone { get; set; }
    }
}
