﻿using Jardineria.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace Jardineria.Data
{
    public partial class UsersContext : IdentityDbContext<JardinUser>
    {
        public UsersContext(DbContextOptions<UsersContext> options) : base(options)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            OnModelCreatingPartial(modelBuilder);
            //SEEDER ROLES
            List<IdentityRole> roles = new List<IdentityRole>() {
                new IdentityRole{Name="admin",NormalizedName="ADMIN"},
                new IdentityRole{Name="basic",NormalizedName="BASIC"},
                new IdentityRole{Name="premium",NormalizedName="PREMIUM"}
            };
            modelBuilder.Entity<IdentityRole>().HasData(roles);

            //SEEDER USERS
            List<JardinUser> users = new List<JardinUser>()
            {
                new JardinUser{
                    UserName="admin@jardin.com",
                    NormalizedUserName="ADMIN@JARDIN.COM",
                    Email="admin@jardin.com",
                    NormalizedEmail="ADMIN@JARDIN.COM",
                    FullName = "Administrador",
                    Address="Calle Canarias 123",
                    PostalCode=12345,
                    Phone=123456789
                },
                new JardinUser{
                    UserName="basic@jardin.com",
                    NormalizedUserName="BASIC@JARDIN.COM",
                    Email="basic@jardin.com",
                    NormalizedEmail="BASIC@JARDIN.COM",
                    FullName = "Usuario Basic",
                    Address="Calle Baleares 456",
                    PostalCode=12345,
                    Phone=123456789
                },
                new JardinUser{
                    UserName="premium@jardin.com",
                    NormalizedUserName="PREMIUM@JARDIN.COM",
                    Email="premium@jardin.com",
                    NormalizedEmail="PREMIUM@JARDIN.COM",
                    FullName = "Usuario Premium",
                    Address="Calle Azores 789",
                    PostalCode=12345,
                    Phone=123456789
                }
            };
            modelBuilder.Entity<JardinUser>().HasData(users);
            var password = new PasswordHasher<JardinUser>();
            users[0].PasswordHash = password.HashPassword(users[0], "Asdf1234!");
            users[1].PasswordHash = password.HashPassword(users[1], "Asdf1234!");
            users[2].PasswordHash = password.HashPassword(users[2], "Asdf1234!");

            List<IdentityUserRole<string>> userRoles = new List<IdentityUserRole<string>>();
            userRoles.Add(new IdentityUserRole<string>
            {
                UserId = users[0].Id,
                RoleId = roles[0].Id,
            });
            userRoles.Add(new IdentityUserRole<string>
            {
                UserId = users[1].Id,
                RoleId = roles[1].Id,
            });
            userRoles.Add(new IdentityUserRole<string>
            {
                UserId = users[2].Id,
                RoleId = roles[2].Id,
            });
            modelBuilder.Entity<IdentityUserRole<string>>().HasData(userRoles);

            base.OnModelCreating(modelBuilder);

        }
        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);

    }
}

