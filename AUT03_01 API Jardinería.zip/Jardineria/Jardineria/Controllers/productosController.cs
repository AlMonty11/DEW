﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Jardineria.Data;
using Jardineria.Models;
using Microsoft.AspNetCore.Authorization;

namespace Jardineria.Controllers
{
    [Route("api/Productos")]
    [ApiController]
    public class productosController : ControllerBase
    {
        private readonly jardineriaContext _context;

        public productosController(jardineriaContext context)
        {
            _context = context;
        }

        // GET: api/productos
        [HttpGet]
        [Authorize(Roles ="admin,basic,premium")]
        public async Task<ActionResult<IEnumerable<producto>>> Getproductos()
        {
          if (_context.productos == null)
          {
              return NotFound();
          }
            return await _context.productos.OrderBy(p=>p.nombre).Take(30).ToListAsync();
        }

        // GET: api/productos/5
        [HttpGet("{id}")]
        [Authorize(Roles = "admin,basic,premium")]

        public async Task<ActionResult<producto>> Getproducto(int id)
        {
          if (_context.productos == null)
          {
              return NotFound();
          }
            var producto = await _context.productos.FirstOrDefaultAsync(p=>p.codigo_producto==id);

            if (producto == null)
            {
                return NotFound();
            }

            return producto;
        }

        // PUT: api/productos/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(Roles = "admin")]
        public async Task<IActionResult> Putproducto(int id, producto producto)
        {
            if (id != producto.codigo_producto)
            {
                return BadRequest();
            }

            _context.Entry(producto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!productoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

    /*    // POST: api/productos
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
      *//*  [HttpPost]
        public async Task<ActionResult<producto>> Postproducto(producto producto)
        {
          if (_context.productos == null)
          {
              return Problem("Entity set 'jardineriaContext.productos'  is null.");
          }
            _context.productos.Add(producto);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Getproducto", new { id = producto.codigo_producto }, producto);
        }
*//*
        // DELETE: api/productos/5
      *//*  [HttpDelete("{id}")]
        public async Task<IActionResult> Deleteproducto(int id)
        {
            if (_context.productos == null)
            {
                return NotFound();
            }
            var producto = await _context.productos.FindAsync(id);
            if (producto == null)
            {
                return NotFound();
            }

            _context.productos.Remove(producto);
            await _context.SaveChangesAsync();

            return NoContent();
        }*/

        private bool productoExists(int id)
        {
            return (_context.productos?.Any(e => e.codigo_producto == id)).GetValueOrDefault();
        }
    }
}
