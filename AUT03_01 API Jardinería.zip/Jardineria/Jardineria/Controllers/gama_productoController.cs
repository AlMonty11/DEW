﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Jardineria.Data;
using Jardineria.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data;

namespace Jardineria.Controllers
{
    [Route("api/Gama")]
    [ApiController]
    public class gama_productoController : ControllerBase
    {
        private readonly jardineriaContext _context;

        public gama_productoController(jardineriaContext context)
        {
            _context = context;
        }

        // GET: api/gama_producto
        [HttpGet]
        [Authorize(Roles = "admin,basic,premium")]

        public async Task<ActionResult<IEnumerable<gama_producto>>> Getgama_productos()
        {
          if (_context.gama_productos == null)
          {
              return NotFound();
          }
            return await _context.gama_productos.ToListAsync();
        }

        // GET: api/gama_producto/5
        [HttpGet("{id}")]
        [Authorize(Roles = "admin,basic,premium")]

        public async Task<ActionResult<gama_producto>> Getgama_producto(string id)
        {
          if (_context.gama_productos == null)
          {
              return NotFound();
          }
            var gama_producto = await _context.gama_productos.Include(g=>g.productos).FirstOrDefaultAsync(g=>g.gama==id);

            if (gama_producto == null)
            {
                return NotFound();
            }

            return gama_producto;
        }

        // PUT: api/gama_producto/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(Roles = "admin")]

        public async Task<IActionResult> Putgama_producto(string id, gama_producto gama_producto)
        {
            gama_producto.gama = id;
            if (id != gama_producto.gama)
            {
                return BadRequest();
            }

            _context.Entry(gama_producto).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!gama_productoExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/gama_producto
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        /*[HttpPost]
        public async Task<ActionResult<gama_producto>> Postgama_producto(gama_producto gama_producto)
        {
          if (_context.gama_productos == null)
          {
              return Problem("Entity set 'jardineriaContext.gama_productos'  is null.");
          }
            _context.gama_productos.Add(gama_producto);
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateException)
            {
                if (gama_productoExists(gama_producto.gama))
                {
                    return Conflict();
                }
                else
                {
                    throw;
                }
            }

            return CreatedAtAction("Getgama_producto", new { id = gama_producto.gama }, gama_producto);
        }*/

       /* // DELETE: api/gama_producto/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Deletegama_producto(string id)
        {
            if (_context.gama_productos == null)
            {
                return NotFound();
            }
            var gama_producto = await _context.gama_productos.FindAsync(id);
            if (gama_producto == null)
            {
                return NotFound();
            }

            _context.gama_productos.Remove(gama_producto);
            await _context.SaveChangesAsync();

            return NoContent();
        }*/

        private bool gama_productoExists(string id)
        {
            return (_context.gama_productos?.Any(e => e.gama == id)).GetValueOrDefault();
        }
    }
}
