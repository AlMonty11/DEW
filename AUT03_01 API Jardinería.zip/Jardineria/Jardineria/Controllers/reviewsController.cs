﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Jardineria.Data;
using Jardineria.Models;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using System.Security.Claims;

namespace Jardineria.Controllers
{
    [Route("api/Reviews")]
    [ApiController]
    public class reviewsController : ControllerBase
    {
        private readonly jardineriaContext _context;
        private readonly UsersContext _usersContext;

        public reviewsController(jardineriaContext context,UsersContext usersContext)
        {
            _context = context;
            _usersContext = usersContext;
        }

        // GET: api/reviews
        /* [HttpGet]
         public async Task<ActionResult<IEnumerable<review>>> Getreview()
         {
             var reviews = await _context.review.ToListAsync();
             if (reviews == null)
             {
                 return NotFound();
             }
             return reviews;
         }*/

        // GET: api/reviews/5
        [HttpGet("{id}")]
        public async Task<ActionResult<review>> Getreview(int id)
        {
            if (_context.review == null)
            {
                return NotFound();
            }
            var review = await _context.review.FindAsync(id);

            if (review == null)
            {
                return NotFound();
            }

            return review;
        }

        // PUT: api/reviews/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        [Authorize(Roles = "admin,premium")]

        public async Task<IActionResult> Putreview(int id, review review)
        {
            if (id != review.Id)
            {
                return BadRequest();
            }

            _context.Entry(review).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!reviewExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return NoContent();
        }

        // POST: api/reviews
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        [Authorize(Roles = "admin,premium")]

        public async Task<ActionResult<review>> Postreview([FromBody] review review)
        {
          if (_context.review == null)
          {
              return Problem("Entity set 'jardineriaContext.review'  is null.");
          }


            _context.review.Add(review);
            await _context.SaveChangesAsync();

            return CreatedAtAction("Getreview", new { id = review.Id }, review);
        }

        // DELETE: api/reviews/5
        [HttpDelete("{id}")]
        [Authorize(Roles = "admin,premium")]

        public async Task<IActionResult> Deletereview(int id)
        {
            if (_context.review == null)
            {
                return NotFound();
            }
            var review = await _context.review.FindAsync(id);
            if (review == null)
            {
                return NotFound();
            }

            _context.review.Remove(review);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool reviewExists(int id)
        {
            return (_context.review?.Any(e => e.Id == id)).GetValueOrDefault();
        }
    }
}
