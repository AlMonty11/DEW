﻿using MessagePack;
using Microsoft.Build.Framework;
using Microsoft.CodeAnalysis;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using KeyAttribute = System.ComponentModel.DataAnnotations.KeyAttribute;
using RequiredAttribute = System.ComponentModel.DataAnnotations.RequiredAttribute;

namespace Jardineria.Models
{
    public partial class review
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [MinLength(3,ErrorMessage ="El campo dbe contener al menos 3 caracteres")]
        [MaxLength(15, ErrorMessage = "El campo dbe contener máximo 15 caracteres")]
        public string Title { get; set; }
        [Required]
        [MinLength(5, ErrorMessage = "El campo dbe contener al menos 5 caracteres")]
        [MaxLength(50, ErrorMessage = "El campo dbe contener máximo 50 caracteres")]
        public string Description { get; set; }
        [Required]
        [Range(1,5)]
        public int Stars { get; set; }
        public int ProductId { get; set; }
        public producto ? Producto { get; set; }
        public int UserId { get; set; }

    }
    /*Title: contiene el title de la review.Será obligatorio y su longitud mínima será de 3 caracteres, y como máximo 15.
Description: Campo obligatorio con una longitud de entre 5 y 50 caracteres.
    Stars: Campo obligatorio, numérico y con un valor entre 1 y 5.
ProductId: Id del producto al que va dirigida la review.
    UserId: Id del usuario creador de la review.*/


}
