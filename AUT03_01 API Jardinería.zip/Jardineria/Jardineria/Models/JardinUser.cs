﻿using MessagePack;
using System.Numerics;
using System.ComponentModel.DataAnnotations;
using KeyAttribute = System.ComponentModel.DataAnnotations.KeyAttribute;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;

namespace Jardineria.Models
{
    public class JardinUser : IdentityUser
    {
        [Required]
        [MinLength(10, ErrorMessage = "El campo debe contener al menos 10 caracteres")]
        public string FullName { get; set; }
        public string ? Address { get; set; } 
        [Range(5,5,ErrorMessage ="El campo debe estar compuesto por 5  cifras")]
        public int PostalCode { get; set; }
        [Range(9,9, ErrorMessage = "El campo debe estar compuesto por 9  cifras")]
        public int Phone { get; set; }
    }
/*    FullName: Nombre completo.Longitud mínima de 10 caracteres.
Address: Dirección del usuario.
PostalCode: Código postal del usuario compuesto por 5 cifras.
Phone: Número telefónico compuesto por 9 cifras.*/

}
